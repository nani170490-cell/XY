import { StyleSheet } from "react-native";
export const colors = { bg: "#09090F", panel: "#151520", border: "#29283A", purple: "#9B7BFF", text: "#F5F3FF", muted: "#A5A1B5" };
export const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg, padding: 18, paddingTop: 58 },
  authWrap: { flex: 1, justifyContent: "center", gap: 14 },
  logo: { color: colors.purple, fontSize: 56, fontWeight: "900", letterSpacing: -3 },
  logoSmall: { color: colors.purple, fontSize: 30, fontWeight: "900" },
  heading: { color: colors.text, fontSize: 28, fontWeight: "800", marginBottom: 6 },
  headerTitle: { color: colors.text, fontSize: 18, fontWeight: "700" },
  muted: { color: colors.muted, fontSize: 14, lineHeight: 21, marginVertical: 6 },
  small: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 8 },
  input: { backgroundColor: colors.panel, color: colors.text, borderColor: colors.border, borderWidth: 1, borderRadius: 13, padding: 15, fontSize: 15, marginVertical: 5 },
  primaryButton: { backgroundColor: colors.purple, borderRadius: 13, padding: 16, alignItems: "center", marginTop: 8 },
  secondaryButton: { backgroundColor: colors.panel, borderColor: colors.border, borderWidth: 1, borderRadius: 13, padding: 15, alignItems: "center", marginVertical: 8 },
  buttonText: { color: "#FFFFFF", fontWeight: "800", fontSize: 15 },
  link: { color: colors.purple, textAlign: "center", fontWeight: "700", padding: 10 },
  row: { flexDirection: "row", gap: 10, alignItems: "center", justifyContent: "center", marginVertical: 8 },
  pill: { borderRadius: 30, borderWidth: 1, borderColor: colors.border, paddingVertical: 10, paddingHorizontal: 28 },
  pillActive: { backgroundColor: "#30234F", borderColor: colors.purple },
  pillText: { color: colors.text, fontWeight: "700" },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 18 },
  notice: { backgroundColor: "#211A35", borderRadius: 10, padding: 12, marginBottom: 14 },
  noticeText: { color: "#D8CCFF", fontSize: 12, lineHeight: 18 },
  preview: { marginVertical: 12 },
  avatar: { width: 86, height: 86, borderRadius: 43, backgroundColor: "#38265F", alignItems: "center", justifyContent: "center", marginVertical: 18 },
  avatarText: { color: "white", fontSize: 32, fontWeight: "800" }
});
