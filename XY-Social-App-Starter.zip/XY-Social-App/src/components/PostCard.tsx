import { Text, View } from "react-native";
import type { Post } from "../types";
import { styles } from "../theme";
export function PostCard({ post }: { post: Post }) {
  return <View style={{ backgroundColor: "#151520", borderColor: "#29283A", borderWidth: 1, borderRadius: 15, padding: 14, marginBottom: 14 }}>
    <Text style={{ color: "#F5F3FF", fontWeight: "800" }}>XY member</Text>
    {!!post.caption && <Text style={{ color: "#F5F3FF", marginTop: 12, lineHeight: 21 }}>{post.caption}</Text>}
    {!!post.media_url && <Text style={styles.link}>{post.media_type === "video" ? "Video post" : "Open media"} · Media URL available</Text>}
    <Text style={styles.small}>{new Date(post.created_at).toLocaleString()}</Text>
  </View>;
}
