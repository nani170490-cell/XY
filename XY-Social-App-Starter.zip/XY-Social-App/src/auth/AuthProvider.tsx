import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "../lib/supabase";
type AuthContextType = {
  session: Session | null; loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<void>;
  sendPhoneOtp: (phone: string) => Promise<void>;
  verifyPhoneOtp: (phone: string, token: string) => Promise<void>;
  signOut: () => Promise<void>;
};
const AuthContext = createContext<AuthContextType | null>(null);
export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setLoading(false); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);
  async function signIn(email: string, password: string) {
    if (!supabase) throw new Error("Supabase is not configured. Follow README setup.");
    const { error } = await supabase.auth.signInWithPassword({ email, password }); if (error) throw error;
  }
  async function signUp(email: string, password: string) {
    if (!supabase) throw new Error("Supabase is not configured. Follow README setup.");
    const { error } = await supabase.auth.signUp({ email, password }); if (error) throw error;
  }
  async function sendPhoneOtp(phone: string) {
    if (!supabase) throw new Error("Supabase is not configured. Follow README setup.");
    const { error } = await supabase.auth.signInWithOtp({ phone }); if (error) throw error;
  }
  async function verifyPhoneOtp(phone: string, token: string) {
    if (!supabase) throw new Error("Supabase is not configured. Follow README setup.");
    const { error } = await supabase.auth.verifyOtp({ phone, token, type: "sms" }); if (error) throw error;
  }
  async function signOut() { if (supabase) { const { error } = await supabase.auth.signOut(); if (error) throw error; } }
  return <AuthContext.Provider value={{ session, loading, signIn, signUp, sendPhoneOtp, verifyPhoneOtp, signOut }}>{children}</AuthContext.Provider>;
}
export function useAuth() {
  const value = useContext(AuthContext); if (!value) throw new Error("useAuth must be inside AuthProvider"); return value;
}
