export type Post = {
  id: string; user_id: string; caption: string | null; media_url: string | null;
  media_type: "image" | "video" | "text"; created_at: string;
};
