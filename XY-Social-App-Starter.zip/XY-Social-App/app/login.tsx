import { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useAuth } from "../src/auth/AuthProvider";
import { styles } from "../src/theme";

export default function LoginScreen() {
  const { signIn, signUp, sendPhoneOtp, verifyPhoneOtp } = useAuth();
  const [mode, setMode] = useState<"email" | "phone">("email");
  const [isNew, setIsNew] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [sent, setSent] = useState(false);

  async function emailAction() {
    try {
      if (!email.trim() || password.length < 8) {
        Alert.alert("Check your details", "Enter an email and a password with at least 8 characters.");
        return;
      }
      if (isNew) await signUp(email.trim(), password);
      else await signIn(email.trim(), password);
      Alert.alert(isNew ? "Check your email" : "Welcome back", isNew ? "Confirm your email if confirmation is enabled in Supabase." : "You are signed in.");
    } catch (e: any) { Alert.alert("Could not continue", e.message ?? "Please try again."); }
  }

  async function phoneAction() {
    try {
      if (!sent) {
        await sendPhoneOtp(phone.trim());
        setSent(true);
        Alert.alert("Code sent", "Enter the verification code sent to your phone.");
      } else {
        await verifyPhoneOtp(phone.trim(), otp.trim());
      }
    } catch (e: any) { Alert.alert("Phone sign-in failed", e.message ?? "Check the number and try again."); }
  }

  return (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.screen}>
      <View style={styles.authWrap}>
        <Text style={styles.logo}>XY</Text>
        <Text style={styles.heading}>Share anything.</Text>
        <Text style={styles.muted}>Connect. Create. Share.</Text>
        <View style={styles.row}>
          <TouchableOpacity style={[styles.pill, mode === "email" && styles.pillActive]} onPress={() => setMode("email")}><Text style={styles.pillText}>Email</Text></TouchableOpacity>
          <TouchableOpacity style={[styles.pill, mode === "phone" && styles.pillActive]} onPress={() => setMode("phone")}><Text style={styles.pillText}>Phone</Text></TouchableOpacity>
        </View>
        {mode === "email" ? <>
          {isNew && <Text style={styles.muted}>Create an account</Text>}
          <TextInput style={styles.input} placeholder="Email address" placeholderTextColor="#858597" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} />
          <TextInput style={styles.input} placeholder="Password (8+ characters)" placeholderTextColor="#858597" secureTextEntry value={password} onChangeText={setPassword} />
          <TouchableOpacity style={styles.primaryButton} onPress={emailAction}><Text style={styles.buttonText}>{isNew ? "Create account" : "Log in"}</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => setIsNew(!isNew)}><Text style={styles.link}>{isNew ? "Already have an account? Log in" : "New to XY? Create an account"}</Text></TouchableOpacity>
        </> : <>
          <TextInput style={styles.input} placeholder="Phone number with country code" placeholderTextColor="#858597" keyboardType="phone-pad" value={phone} onChangeText={setPhone} />
          {sent && <TextInput style={styles.input} placeholder="Verification code" placeholderTextColor="#858597" keyboardType="number-pad" value={otp} onChangeText={setOtp} />}
          <TouchableOpacity style={styles.primaryButton} onPress={phoneAction}><Text style={styles.buttonText}>{sent ? "Verify code" : "Send code"}</Text></TouchableOpacity>
          <Text style={styles.small}>Phone OTP must be enabled and configured in your Supabase project.</Text>
        </>}
        <Text style={styles.small}>By continuing, you agree to use XY respectfully and follow its community rules.</Text>
      </View>
    </KeyboardAvoidingView>
  );
}
