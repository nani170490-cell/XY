import { useState } from "react";
import { Alert, Image, Text, TextInput, TouchableOpacity, View } from "react-native";
import * as ImagePicker from "expo-image-picker";
import { supabase } from "../../src/lib/supabase";
import { useAuth } from "../../src/auth/AuthProvider";
import { styles } from "../../src/theme";

export default function CreateScreen() {
  const { session } = useAuth();
  const [caption, setCaption] = useState("");
  const [asset, setAsset] = useState<ImagePicker.ImagePickerAsset | null>(null);
  const [busy, setBusy] = useState(false);

  async function chooseMedia() {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images", "videos"], allowsEditing: true, quality: 0.85, videoMaxDuration: 60 });
    if (!result.canceled) setAsset(result.assets[0]);
  }
  async function publish() {
    if (!supabase || !session?.user || !asset) {
      Alert.alert("Setup needed", "Connect Supabase and sign in before publishing media.");
      return;
    }
    setBusy(true);
    try {
      const response = await fetch(asset.uri);
      const blob = await response.blob();
      const ext = (asset.fileName?.split(".").pop() || (asset.type === "video" ? "mp4" : "jpg")).toLowerCase();
      const path = `${session.user.id}/${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage.from("post-media").upload(path, blob, { contentType: asset.mimeType || (asset.type === "video" ? "video/mp4" : "image/jpeg") });
      if (uploadError) throw uploadError;
      const { data: urlData } = supabase.storage.from("post-media").getPublicUrl(path);
      const { error } = await supabase.from("posts").insert({ user_id: session.user.id, caption, media_url: urlData.publicUrl, media_type: asset.type === "video" ? "video" : "image", visibility: "public" });
      if (error) throw error;
      setCaption(""); setAsset(null); Alert.alert("Published", "Your post is now on XY.");
    } catch (e: any) { Alert.alert("Could not publish", e.message ?? "Try again."); }
    finally { setBusy(false); }
  }
  return <View style={styles.screen}>
    <Text style={styles.heading}>Create a post</Text>
    <Text style={styles.muted}>Share a photo or a short video (up to 60 seconds in this starter).</Text>
    <TextInput style={[styles.input, { minHeight: 110, textAlignVertical: "top" }]} multiline placeholder="Write a caption…" placeholderTextColor="#858597" value={caption} onChangeText={setCaption} />
    <TouchableOpacity style={styles.secondaryButton} onPress={chooseMedia}><Text style={styles.buttonText}>Choose photo or video</Text></TouchableOpacity>
    {asset && <View style={styles.preview}>{asset.type === "image" ? <Image source={{ uri: asset.uri }} style={{ width: "100%", height: 220, borderRadius: 12 }} /> : <Text style={styles.muted}>Video selected: {asset.fileName || "video file"}</Text>}</View>}
    <TouchableOpacity style={styles.primaryButton} disabled={busy} onPress={publish}><Text style={styles.buttonText}>{busy ? "Publishing…" : "Publish"}</Text></TouchableOpacity>
    <Text style={styles.small}>Stories and short-video feeds are planned next; this screen currently supports image/video posts.</Text>
  </View>;
}
