import { useEffect, useState } from "react";
import { FlatList, Text, TouchableOpacity, View } from "react-native";
import { PostCard } from "../../src/components/PostCard";
import { supabase } from "../../src/lib/supabase";
import { styles } from "../../src/theme";
import type { Post } from "../../src/types";

export default function HomeScreen() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  async function load() {
    if (!supabase) { setLoading(false); return; }
    const { data, error } = await supabase.from("posts").select("id, user_id, caption, media_url, media_type, created_at").eq("visibility", "public").order("created_at", { ascending: false }).limit(30);
    if (!error && data) setPosts(data as Post[]);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);
  return <View style={styles.screen}>
    <View style={styles.header}><Text style={styles.logoSmall}>XY</Text><Text style={styles.headerTitle}>For you</Text><TouchableOpacity onPress={load}><Text style={styles.link}>Refresh</Text></TouchableOpacity></View>
    <View style={styles.notice}><Text style={styles.noticeText}>Be kind. Share safely. Only post content you have permission to share.</Text></View>
    {!supabase ? <Text style={styles.muted}>Connect Supabase using your .env file to load real posts. Your app UI is ready.</Text> :
      loading ? <Text style={styles.muted}>Loading posts…</Text> :
      <FlatList data={posts} keyExtractor={(item) => item.id} renderItem={({ item }) => <PostCard post={item} />} ListEmptyComponent={<Text style={styles.muted}>No posts yet. Be the first to share something!</Text>} />}
  </View>;
}
