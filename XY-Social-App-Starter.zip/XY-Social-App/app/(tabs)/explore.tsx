import { Text, TextInput, View } from "react-native";
import { styles } from "../../src/theme";
export default function ExploreScreen() {
  return <View style={styles.screen}><Text style={styles.heading}>Explore</Text><TextInput style={styles.input} placeholder="Search people and posts" placeholderTextColor="#858597" /><Text style={styles.muted}>Discover public posts and accounts. Search will be connected to Supabase in the next iteration.</Text></View>;
}
