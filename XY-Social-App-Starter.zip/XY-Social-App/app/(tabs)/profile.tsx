import { Alert, Text, TouchableOpacity, View } from "react-native";
import { useAuth } from "../../src/auth/AuthProvider";
import { styles } from "../../src/theme";
export default function ProfileScreen() {
  const { session, signOut } = useAuth();
  return <View style={styles.screen}>
    <Text style={styles.heading}>Your profile</Text>
    <View style={styles.avatar}><Text style={styles.avatarText}>{session?.user.email?.[0]?.toUpperCase() || "X"}</Text></View>
    <Text style={styles.headerTitle}>{session?.user.email || "XY member"}</Text>
    <Text style={styles.muted}>Add a username, bio and profile photo in the next profile iteration.</Text>
    <TouchableOpacity style={styles.secondaryButton} onPress={() => Alert.alert("Privacy", "Profile privacy controls are planned before public launch.")}><Text style={styles.buttonText}>Privacy & safety</Text></TouchableOpacity>
    <TouchableOpacity style={styles.primaryButton} onPress={signOut}><Text style={styles.buttonText}>Log out</Text></TouchableOpacity>
  </View>;
}
