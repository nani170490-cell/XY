import { Text, View } from "react-native";
import { styles } from "../../src/theme";
export default function InboxScreen() {
  return <View style={styles.screen}><Text style={styles.heading}>Inbox</Text><Text style={styles.muted}>Messaging will be enabled after user blocking, privacy controls and reporting are in place. This protects people from unwanted messages.</Text></View>;
}
